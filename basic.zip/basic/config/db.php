<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=localhost;port=5432;dbname=sed',
    'username' => 'sed',
    'password' => '12sed34',
    'charset' => 'utf8',
];
